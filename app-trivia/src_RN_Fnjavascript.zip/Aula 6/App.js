import Trivia from './componentes/trivia';

export default function App() {
  return (
    <>
      <Trivia />
    </>
  );
}