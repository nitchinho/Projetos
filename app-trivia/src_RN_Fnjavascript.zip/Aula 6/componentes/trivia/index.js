import { useState } from 'react';
import { Button, Text, TextInput, View } from 'react-native';
import { buscaFatos, checaRespostaCerta } from '../../servicos/buscaFatos';

import styles from './styles';

export default function Trivia() {

  const [pergunta, setPergunta] = useState(buscaFatos());
  const [respostaUsuario, setRespostaUsuario] = useState(0);
  const [acertou, setAcertou] = useState();

  function handleResposta() {
      const respostaCerta = checaRespostaCerta(respostaUsuario, pergunta.Ano);
      setAcertou(respostaCerta);
  }

  function handleProxima() {
    setAcertou();
    setRespostaUsuario();
    setPergunta(buscaFatos());
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Trivia - Fatos Históricos</Text>
      <Text style={styles.subtitulo}>Em que ano ocorreu esse fato?</Text>
      { 
        (acertou === true) 
        ?
        <View style={styles.acertouArea}>
          <Text style={styles.status}>Você Acertou</Text>
          <Button style={styles.btnProxima} onPress={handleProxima} title="Próxima Pergunta" />
        </View>
        : (acertou === false) ?
        <View style={styles.errouArea}>
          <Text style={styles.status}>Você Errou</Text>
          <Button style={styles.btnProxima} onPress={handleProxima} title="Próxima Pergunta" />
        </View>
        :
        <>
        </>
      }
      <Text style={styles.pergunta}>Fato: {pergunta.Fato}</Text>
      <TextInput style={styles.input} 
        value={respostaUsuario} 
        onChangeText={(respostaDigitada) => setRespostaUsuario(respostaDigitada)} 
      placeholder='Resposta' />
      <Button onPress={handleResposta} title='Responder' />
    </View>
  );
}