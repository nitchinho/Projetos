import Game from './componentes/Game';

export default function App() {

  return (
    <>
      <Game />
    </>
  );
}
