import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({   
    coluna: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',

      width: 110,
      height: 110,

    },

    marcadorJogador: {
        fontSize: 60,
    }
});

export default styles;
